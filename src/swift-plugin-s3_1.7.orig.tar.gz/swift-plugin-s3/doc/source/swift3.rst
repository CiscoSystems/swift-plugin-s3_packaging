.. _swift3_package:

swift3
==============

.. automodule:: swift3
    :members:
    :undoc-members:
    :show-inheritance:

swift3.middleware
=========================

.. automodule:: swift3.middleware
    :members:
    :undoc-members:
    :show-inheritance:
